<?php
$_adminer_dir = dirname(__FILE__) . "/adminer";

function adminer_object() {
    global $_adminer_dir;

    // required to run any plugin
    // look here for API https://github.com/vrana/adminer/blob/master/plugins/plugin.php
    include_once("$_adminer_dir/plugin.php");

    class MyAdminer extends AdminerPlugin {
        function name() {
            // custom name in title and heading
            return 'DB - SMPX';
        }
        
        function permanentLogin($create = false) {
            // key used for permanent login
            return "kVPHMGedyJZxrP4KsSMUcwRFA3liEnIr";
        }
        
        // function credentials() {
        //     // server, username and password for connecting to database
        //     return array('localhost', 'ODBC', '');
        // }
        
        // function database() {
        //     // database name, will be escaped by Adminer
        //     return 'software';
        // }
        
        // function login($login, $password) {
        //     // validate user submitted credentials
        //     return ($login == 'admin' && $password == '');
        // }
        
        // function tableName($tableStatus) {
        //     // tables without comments would return empty string and will be ignored by Adminer
        //     return h($tableStatus["Comment"]);
        // }
        
        // function fieldName($field, $order = 0) {
        //     // only columns with comments will be displayed and only the first five in select
        //     return ($order <= 5 && !preg_match('~_(md5|sha1)$~', $field["field"]) ? h($field["comment"]) : "");
        // }
    }
    
    // autoloader
    foreach (glob("$_adminer_dir/plugins/*.php") as $filename) {
        include_once($filename);
    }
    
    $plugins = array(
        // specify enabled plugins here
        // AdminerDumpAlter doesn't work with postresql
        new AdminerDumpAlter,
        new AdminerDumpJson,
        new AdminerDumpXml,
        new AdminerJsonColumn,
    );
    
    /* It is possible to combine customization and plugins:
    class AdminerCustomization extends AdminerPlugin {
    }
    return new AdminerCustomization($plugins);
    */
    
    return new MyAdminer($plugins);
}

// include original Adminer or Adminer Editor
include("$_adminer_dir/adminer.php");
?>