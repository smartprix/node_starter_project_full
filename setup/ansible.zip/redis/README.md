# Multiple Redis Instances
Taken from: http://robofirm.com/insights/2014/04/setting-up-multiple-redis-instances-on-a-single-magento-server/

## Init Script
```bash
cd /etc/init.d
mv redis-server redis-server.bak
cp /smartprix/app/conf/redis/redis-server .
chmod 0755 redis-server
```

## Server Config
```bash
cd /etc/redis
mkdir servers
cd servers
cp -R /smartprix/app/conf/redis/servers/* .
```

To make any new servers you need to copy `main.conf` and change the filename to `{server_name}.conf`. You also need to change the following configurations.
```bash
pidfile /var/run/redis/{server_name}.pid
port 637{*}
logfile /smartprix/logs/server_logs/redis_{server_name}.log
dbfilename {server_name}.rdb
```

To find out the an empty port you can run
```bash
# Determine the lowest port number
grep -hR ^port . | sort
# Use port 1 less than the lowest port
```

Tune Redis by turning on overcommit memory
```bash
echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
sysctl -p

# Alternatively
# echo 1 > /proc/sys/vm/overcommit_memory
```

Now you can restart all instances with
```bash
service redis-server restart
```

Or you can just restart one instance with
```bash
service redis-server restart server_name
```