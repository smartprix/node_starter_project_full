package smart.prix;

import smart.prix.SmartSimilarity;
import org.apache.solr.common.params.SolrParams;
import org.apache.lucene.search.similarities.Similarity;
import org.apache.solr.search.similarities.DefaultSimilarityFactory;

public class SmartSimilarityFactory extends DefaultSimilarityFactory
{
	protected float idfPower = 0.33f;
	protected float idfMultiply = 0.2f;
	protected float tfPower = 1.0f;
	protected float tfMultiply = 0.3f;
	protected float coordPower = 3.0f;
	protected float coordMultiply = 1.0f;
	protected float normPower = 1.0f;
	protected float normMultiply = 1.0f;

	@Override
	public void init(SolrParams params) 
	{
		super.init(params);

		idfPower = params.getFloat("idfPower", idfPower);
		idfMultiply = params.getFloat("idfMultiply", idfMultiply);
		tfPower = params.getFloat("tfPower", tfPower);
		tfMultiply = params.getFloat("tfMultiply", tfMultiply);
		coordPower = params.getFloat("coordPower", coordPower);
		coordMultiply = params.getFloat("coordMultiply", coordMultiply);
		normPower = params.getFloat("idfPower", normPower);
		normMultiply = params.getFloat("idfPower", normMultiply);
	}

	@Override
	public Similarity getSimilarity() 
	{
		SmartSimilarity sim = new SmartSimilarity();

		sim.setDiscountOverlaps(discountOverlaps);

		sim.idfPower = idfPower;
		sim.idfMultiply = idfMultiply;
		sim.tfPower = tfPower;
		sim.tfMultiply = tfMultiply;
		sim.coordPower = coordPower;
		sim.coordMultiply = coordMultiply;
		sim.normPower = normPower;
		sim.normMultiply = normMultiply;

		return sim;
	}
}